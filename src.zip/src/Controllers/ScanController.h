#ifndef SCAN_CONTROLLER_H
#define SCAN_CONTROLLER_H

#include <Interfaces/IDisplayView.h>
#include <Interfaces/IInputProvider.h>
#include <Services/ProductService.h>
#include <Services/RemoteService.h>
#include <Services/InfraredService.h>
#include <Contexts/GlobalContext.h>
#include <Contexts/SelectionContext.h>
#include <Selections/ScanSelection.h>
#include <Models/Remote.h>
#include <Models/Product.h>

using namespace services;
using namespace contexts;
using namespace selections;
using namespace models;

namespace controllers {

class ScanController {
public:
    ScanController(interfaces::IDisplayView& display, interfaces::IInputProvider& input, ProductService& productService, 
                   RemoteService& remoteService, InfraredService& infraredService, 
                   ScanSelection& ScanSelection);

    void handleScanSelection();

private:
    interfaces::IDisplayView& display;
    interfaces::IInputProvider& input;
    ProductService& productService;
    ScanSelection& scanSelection;
    RemoteService& remoteService;
    InfraredService& infraredService;
    GlobalContext& globalContext = GlobalContext::getInstance();
    SelectionContext& selectionContext = SelectionContext::getInstance();
};

} // namespace controllers

#endif // SCAN_CONTROLLER_H
